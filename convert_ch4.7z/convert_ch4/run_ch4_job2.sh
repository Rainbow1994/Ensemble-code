python2.7 job_launch_ch4_npz2.py 1 > t1.out & 
python2.7 job_launch_ch4_npz2.py 2 > t2.out & 
python2.7 job_launch_ch4_npz2.py 3 > t3.out & 
python2.7 job_launch_ch4_npz2.py 4 > t4.out & 
python2.7 job_launch_ch4_npz2.py 5 > t5.out & 
python2.7 job_launch_ch4_npz2.py 6 > t6.out & 
python2.7 job_launch_ch4_npz2.py 7 > t7.out &

