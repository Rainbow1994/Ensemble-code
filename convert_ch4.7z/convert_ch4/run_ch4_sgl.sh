python2.7 job_launch_ch4_npz.py 1 > t1.out & 
