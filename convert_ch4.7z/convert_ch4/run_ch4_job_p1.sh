python2.7 job_launch_ch4_npz.py 2016 1 > t54.out & 
python2.7 job_launch_ch4_npz.py 2016 2 > t55.out & 
python2.7 job_launch_ch4_npz.py 2016 3 > t56.out & 
python2.7 job_launch_ch4_npz.py 2016 4 > t57.out &
python2.7 job_launch_ch4_npz.py 2016 5 > t65.out & 
python2.7 job_launch_ch4_npz.py 2016 6 > t66.out & 
python2.7 job_launch_ch4_npz.py 2016 7 > t67.out &









