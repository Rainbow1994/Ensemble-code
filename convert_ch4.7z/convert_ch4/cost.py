transport=160+540+190+1150+470+160+160+2540+2540
print 'transport=', transport
dinner_japan=5599+880+2100+4460+370
print 'd_in_J', dinner_japan
hotel=40297
print 'hotel', hotel
sum_japan=transport+dinner_japan+hotel
print '*'*10
print 'sum_japan', sum_japan


dinner_holland=51+5.40
print 'd_in_h', dinner_holland

flight=1369.5
visa=13.00
tax_bus=20.0+8.00+3.0
seat_update=41.63
print 'visa', visa
print 'flight',flight 
print 'tax_bus', visa
print 'seat_update', seat_update
sum_uk=flight+visa+tax_bus+seat_update
print 'sum_uk', sum_uk





