from numpy import *
import usa_std_atmosphere as uatmo
def get_pressure(alt):
    density,pressure,temperature = uatmo.atmosphere(alt)
    return pressure
def get_pressure_array(alt_array):
    pressure_array=list()
    for alt in alt_array:
        density,pressure,temperature = uatmo.atmosphere(alt)
        pressure_array.append(pressure)
        
    pressure_array=array(pressure_array)
    return pressure_array

def get_density(alt):
    density,pressure,temperature = uatmo.atmosphere(alt)
    return density
def get_temperature(alt):
    density,pressure,temperature = uatmo.atmosphere(alt)
    return temperature

def get_altitude(pressure):
    z=0.0
    dz=1.0
    nz=80
    zl=0.0
    zr=0.0
    pl=0.0
    pr=0.0
    for iz in range(nz):
        pres=get_pressure(z)
        if (pres<pressure):
            zr=z
            pr=pres
            break
        else:
            zl=z
            pl=pres
        z=z+dz


    if (zr>zl):
        dzdp=(zr-zl)/log10(pr/pl)
        z=zl+dzdp*log10(pressure/pl)
    else:
        z=zr

    return z

if (__name__=='__main__'):
    z=get_altitude(800.0)
    print z
    pres=get_pressure(5.0)
    print pres
    pres=get_pressure(8.0)
    print pres
    
    temp=get_temperature(16)
    print temp
    
        
        
    

