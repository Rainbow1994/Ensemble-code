a='ddddd'
s=r'%10.10s' % (a)
print s
