python2.7 job_launch_ch4_npz.py 1 > t1.out & 
python2.7 job_launch_ch4_npz.py 2 > t2.out & 
python2.7 job_launch_ch4_npz.py 3 > t3.out & 

