python2.7 job_launch_ch4_npz.py 2009 4 > t94.out & 
python2.7 job_launch_ch4_npz.py 2009 5 > t95.out & 
python2.7 job_launch_ch4_npz.py 2009 6 > t96.out & 
python2.7 job_launch_ch4_npz.py 2009 7 > t97.out & 


python2.7 job_launch_ch4_npz.py 2010 4 > t04.out & 
python2.7 job_launch_ch4_npz.py 2010 5 > t05.out & 
python2.7 job_launch_ch4_npz.py 2010 6 > t06.out & 
python2.7 job_launch_ch4_npz.py 2010 7 > t07.out & 



python2.7 job_launch_ch4_npz.py 2011 4 > t14.out & 
python2.7 job_launch_ch4_npz.py 2011 5 > t15.out & 
python2.7 job_launch_ch4_npz.py 2011 6 > t16.out & 
python2.7 job_launch_ch4_npz.py 2011 7 > t17.out & 


python2.7 job_launch_ch4_npz.py 2012 4 > t24.out & 
python2.7 job_launch_ch4_npz.py 2012 5 > t25.out & 
python2.7 job_launch_ch4_npz.py 2012 6 > t26.out & 
python2.7 job_launch_ch4_npz.py 2012 7 > t27.out & 


python2.7 job_launch_ch4_npz.py 2013 4 > t34.out & 
python2.7 job_launch_ch4_npz.py 2013 5 > t35.out & 
python2.7 job_launch_ch4_npz.py 2013 6 > t36.out & 
python2.7 job_launch_ch4_npz.py 2013 7 > t37.out & 


python2.7 job_launch_ch4_npz.py 2014 4 > t44.out & 
python2.7 job_launch_ch4_npz.py 2014 5 > t45.out & 
python2.7 job_launch_ch4_npz.py 2014 6 > t46.out & 
python2.7 job_launch_ch4_npz.py 2014 7 > t47.out & 

python2.7 job_launch_ch4_npz.py 2015 4 > t54.out & 
python2.7 job_launch_ch4_npz.py 2015 5 > t55.out & 
python2.7 job_launch_ch4_npz.py 2015 6 > t56.out & 
python2.7 job_launch_ch4_npz.py 2015 7 > t57.out & 

