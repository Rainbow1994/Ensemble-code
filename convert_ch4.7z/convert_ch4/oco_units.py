from numpy import *
import geo_constant as gc
unit_stv='kg/s'
unit_flux_geos_chem='mole/cm2/s'
kg_s_to_GtC_Y=gc.mc*3600.0*365*24.0/(1.0e12*gc.mco2)

