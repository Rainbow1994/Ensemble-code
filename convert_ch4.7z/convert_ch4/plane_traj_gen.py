from pylab import *
from numpy import *
head_lines=['PLANEFLIGHT.DAT', \
            'LIANG FENG', \
            '12 DEC 2008', \
            '   ' \
            ]
fl_traj=open('aircraft_line.dat')
second_lines=
all_lines=fl_traj.readlines()
end_lines='END 0- 0- - 0: 0 0.00 0.00 0.00'


